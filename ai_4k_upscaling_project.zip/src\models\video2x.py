# src/models/video2x.py
"""Video2X model stub.

Placeholder for a generic video‑upscaling model (e.g., a TensorRT or ONNX
implementation). The real version would up‑scale frames using a deep‑learning
network; here we simply pass frames through unchanged.
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


def load_model() -> Any:
    """Placeholder loader for the Video2X model."""
    logger.info("Loading Video2X model (placeholder)")
    return object()


def enhance(frame: Any, model: Any = None) -> Any:
    """Placeholder enhancement – returns the input unchanged."""
    logger.debug("Enhancing frame with Video2X stub")
    return frame
