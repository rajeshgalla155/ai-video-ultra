@echo off
rem -------------------------------------------------------------------
rem Run script for AI Video Clarity Enhancer
rem -------------------------------------------------------------------
rem Create virtual environment if not exists
if not exist venv (python -m venv venv)

rem Activate virtual environment
call venv\Scripts\activate

rem Upgrade pip and install dependencies
python -m pip install --upgrade pip
pip install -r requirements.txt

rem Launch the application
python src\main.py
