# src/app/hardware.py
"""Hardware detection utilities.
Detects CPU, RAM, GPU capabilities (CUDA, Vulkan) and returns a summary dict.
"""
import platform
import psutil

def get_cpu_info():
    return {
        "processor": platform.processor(),
        "cores": psutil.cpu_count(logical=False),
        "threads": psutil.cpu_count(logical=True),
    }

def get_ram_info():
    vm = psutil.virtual_memory()
    return {
        "total_gb": round(vm.total / (1024**3), 2),
        "available_gb": round(vm.available / (1024**3), 2),
    }

def get_cuda_info():
    try:
        import torch
        if torch.cuda.is_available():
            dev = torch.cuda.get_device_properties(0)
            return {
                "name": dev.name,
                "total_vram_gb": round(dev.total_memory / (1024**3), 2),
                "capability": f"{dev.major}.{dev.minor}",
                "available": True,
            }
    except Exception:
        pass
    return {"available": False}

def get_vulkan_info():
    # Placeholder – full Vulkan detection requires additional libs; we report availability flag.
    try:
        import vulkan
        # If import succeeds, assume driver present.
        return {"available": True}
    except Exception:
        return {"available": False}

def detect_hardware():
    info = {
        "cpu": get_cpu_info(),
        "ram": get_ram_info(),
        "cuda": get_cuda_info(),
        "vulkan": get_vulkan_info(),
    }
    # Determine best GPU path
    info["gpu_available"] = info["cuda"]["available"] or info["vulkan"]["available"]
    return info
