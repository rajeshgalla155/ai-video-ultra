# src/app/__init__.py
"""Application package for AI Video Clarity Enhancer.
Provides entry points and initial package setup.
"""
