# src/app/pipeline/__init__.py
"""Pipeline package placeholder.
Contains decoder, batcher, enhancer, encoder modules.
"""
