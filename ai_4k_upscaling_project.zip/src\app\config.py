# src/app/config.py
"""Configuration dataclasses for the AI Video Clarity Enhancer.
Defines user‑selectable settings and internal defaults.
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

class ResolutionOption(str, Enum):
    P1080 = "1080p"
    P2K = "2K"
    P4K = "4K"

class ModeOption(str, Enum):
    FAST = "Fast"
    BALANCED = "Balanced"
    QUALITY = "Quality"

@dataclass
class AppSettings:
    """Container for runtime settings chosen by the user."""
    input_path: Path = Path("")
    output_path: Path = Path("")
    resolution: ResolutionOption = ResolutionOption.P1080
    mode: ModeOption = ModeOption.BALANCED
    # These will be filled after hardware detection / benchmarking
    estimated_fps: float = 0.0
    estimated_time_sec: float = 0.0
    # Internal flag for whether GPU acceleration is available
    gpu_available: bool = False
    # Path to the selected AI model (filled by engine based on mode)
    model_path: Path = Path("")

    def to_dict(self):
        return {
            "input_path": str(self.input_path),
            "output_path": str(self.output_path),
            "resolution": self.resolution.value,
            "mode": self.mode.value,
            "estimated_fps": self.estimated_fps,
            "estimated_time_sec": self.estimated_time_sec,
            "gpu_available": self.gpu_available,
            "model_path": str(self.model_path),
        }

    @staticmethod
    def from_dict(data: dict) -> "AppSettings":
        return AppSettings(
            input_path=Path(data.get("input_path", "")),
            output_path=Path(data.get("output_path", "")),
            resolution=ResolutionOption(data.get("resolution", ResolutionOption.P1080.value)),
            mode=ModeOption(data.get("mode", ModeOption.BALANCED.value)),
            estimated_fps=data.get("estimated_fps", 0.0),
            estimated_time_sec=data.get("estimated_time_sec", 0.0),
            gpu_available=data.get("gpu_available", False),
            model_path=Path(data.get("model_path", "")),
        )
