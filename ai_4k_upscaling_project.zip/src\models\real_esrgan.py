# src/models/real_esrgan.py
"""Real‑ESRGAN model stub.

In the full implementation this module would load the pretrained Real‑ESRGAN
weights (ONNX or PyTorch) and expose an `enhance(frame: np.ndarray) -> np.ndarray`
method that up‑scales a single image/frame.

For now we provide a minimal placeholder that simply returns the input frame
unchanged and logs the call.
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


def load_model() -> Any:
    """Placeholder for loading the Real‑ESRGAN model.

    Returns a dummy object; real code would return the model instance.
    """
    logger.info("Loading Real‑ESRGAN model (placeholder)")
    return object()


def enhance(frame: Any, model: Any = None) -> Any:
    """Placeholder enhancement – returns the frame unchanged.

    Parameters
    ----------
    frame: Any
        Image data (e.g., a NumPy array). In the placeholder we accept any type.
    model: Any, optional
        The loaded model; ignored in the stub.
    """
    logger.debug("Enhancing frame with Real‑ESRGAN stub")
    return frame
