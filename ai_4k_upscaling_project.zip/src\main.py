import sys
from PySide6.QtWidgets import QApplication
from src.ui.main_window import MainWindow

def main():
    app = QApplication(sys.argv)
    # Apply dark theme stylesheet (simple placeholder)
    app.setStyleSheet("""
        QWidget { background-color: #121212; color: #E0E0E0; }
        QPushButton { background-color: #0066CC; color: white; border-radius: 5px; padding: 5px; }
        QPushButton:hover { background-color: #0099FF; }
        QProgressBar { border: 1px solid #555; background-color: #222; text-align: center; }
        QProgressBar::chunk { background-color: #00CC66; }
    """)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
