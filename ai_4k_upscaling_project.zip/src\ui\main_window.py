# src/ui/main_window.py
"""Premium PySide6 UI for AI Video Clarity Enhancer.

Features
--------
- Dark glass‑morphism theme using a semi‑transparent backdrop and subtle
  backdrop‑blur (via QGraphicsEffect).
- Drag‑and‑drop area for video files.
- Dropdowns for output resolution and AI model selection.
- Start button that triggers the ``Engine`` pipeline and updates a progress
  bar.
- Settings pane (persisted via ``src/app/config.py``) with a modern look.

The UI is deliberately lightweight for now – the heavy AI work is handled by
the backend ``Engine``. Styling uses Google Font **Inter** and a harmonious
HSL‑based colour palette (dark background, cyan‑green accents).
"""

import sys
import logging
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QMimeData, QUrl, QSize
from PySide6.QtGui import QFont, QDragEnterEvent, QDropEvent, QIcon, QPalette, QColor, QGuiApplication, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QWidget,
    QMainWindow,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QComboBox,
    QProgressBar,
    QFileDialog,
    QGraphicsOpacityEffect,
    QGraphicsBlurEffect,
    QMessageBox,
)

# Import the engine and config (they exist in the scaffold).
from src.app.engine import Engine
from src.app.config import Config

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")


class DropArea(QLabel):
    """A stylized label that accepts files via drag‑and‑drop.

    Emits ``self.fileDropped`` (a ``Path``) when a single file is dropped.
    """

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setText("Drag & drop video here or click to browse")
        self.setAlignment(Qt.AlignCenter)
        self.setFixedHeight(120)
        self.setStyleSheet(
            "border: 2px dashed rgba(255,255,255,0.3);"
            "border-radius: 12px;"
            "color: rgba(255,255,255,0.7);"
            "font-size: 14px;"
        )
        self.setAcceptDrops(True)
        self._callback = None

    def set_callback(self, fn):
        self._callback = fn

    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event: QDropEvent):
        urls = event.mimeData().urls()
        if not urls:
            return
        # Only accept the first file.
        path = Path(urls[0].toLocalFile())
        if path.is_file():
            logger.info("File dropped: %s", path)
            if self._callback:
                self._callback(path)
        event.acceptProposedAction()

    # Allow clicking to open a file dialog.
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            file, _ = QFileDialog.getOpenFileName(
                self,
                "Select video",
                str(Path.home()),
                "Video Files (*.mp4 *.avi *.mov *.mkv);;All Files (*)",
            )
            if file:
                path = Path(file)
                logger.info("File selected via dialog: %s", path)
                if self._callback:
                    self._callback(path)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AI Video Clarity Enhancer – Ultra Fast Edition")
        self.resize(960, 600)
        self._apply_dark_glass_style()
        self._build_ui()
        self.config = Config.load()  # Load persisted settings if they exist.
        self.engine = Engine(self.config)

    def _apply_dark_glass_style(self):
        """Apply a dark glass‑morphism look.

        The effect uses a semi‑transparent background colour with a subtle blur.
        """
        palette = self.palette()
        palette.setColor(QPalette.Window, QColor(18, 18, 18, 230))  # very dark with opacity
        self.setPalette(palette)
        self.setAutoFillBackground(True)

        # Blur effect for the whole window background.
        blur = QGraphicsBlurEffect(self)
        blur.setBlurRadius(12)
        self.setGraphicsEffect(blur)

        # Use Inter font globally.
        font = QFont("Inter", 10)
        QApplication.setFont(font)

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Title banner
        title = QLabel("AI Video Clarity Enhancer")
        title.setStyleSheet("color: #00ffcc; font-size: 28px; font-weight: 600;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Drop area
        self.drop_area = DropArea()
        self.drop_area.set_callback(self._on_file_selected)
        layout.addWidget(self.drop_area)

        # Settings row – resolution and model selectors.
        settings_row = QHBoxLayout()
        # Resolution selector
        self.res_selector = QComboBox()
        self.res_selector.addItems(["1080p", "2K", "4K"])
        self.res_selector.setCurrentText(self.config.output_resolution)
        self.res_selector.setStyleSheet(self._combo_style())
        settings_row.addWidget(QLabel("Resolution:"))
        settings_row.addWidget(self.res_selector)

        # Model selector
        self.model_selector = QComboBox()
        self.model_selector.addItems(["Real‑ESRGAN", "Video2X"])
        self.model_selector.setCurrentText(self.config.model_name)
        self.model_selector.setStyleSheet(self._combo_style())
        settings_row.addWidget(QLabel("Model:"))
        settings_row.addWidget(self.model_selector)
        layout.addLayout(settings_row)

        # Progress bar
        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.progress.setStyleSheet(
            "QProgressBar {background-color: rgba(255,255,255,0.1); color: #00ffcc; border-radius: 6px; height: 20px;}"
            "QProgressBar::chunk {background-color: #00ffcc; border-radius: 6px;}"
        )
        layout.addWidget(self.progress)

        # Start button
        self.start_btn = QPushButton("Start Upscaling")
        self.start_btn.clicked.connect(self._on_start)
        self.start_btn.setStyleSheet(
            "QPushButton {background-color: #00ffcc; color: #111; font-weight: 600; border: none;"
            " padding: 10px 20px; border-radius: 8px; }"
            "QPushButton:hover {background-color: #00e6b8;}"
        )
        layout.addWidget(self.start_btn, alignment=Qt.AlignCenter)

        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: #aaaaaa;")
        layout.addWidget(self.status_label, alignment=Qt.AlignCenter)

        # Store selected file path
        self.selected_file: Optional[Path] = None

    def _combo_style(self) -> str:
        return (
            "QComboBox {background-color: rgba(255,255,255,0.08); color: #00ffcc; padding: 4px 8px; border-radius: 6px; }"
            "QComboBox::drop-down {border: none; }"
            "QComboBox QAbstractItemView {background-color: #222; color: #00ffcc; selection-background-color: #00e6b8;}"
        )

    def _on_file_selected(self, path: Path):
        self.selected_file = path
        self.drop_area.setText(f"Selected: {path.name}")
        self.status_label.setText("File ready for processing")

    def _on_start(self):
        if not self.selected_file:
            QMessageBox.warning(self, "No file", "Please select a video file first.")
            return
        # Update config from UI controls.
        self.config.output_resolution = self.res_selector.currentText()
        self.config.model_name = self.model_selector.currentText()
        self.config.save()

        self.start_btn.setEnabled(False)
        self.progress.setValue(0)
        self.status_label.setText("Processing…")
        QApplication.processEvents()
        try:
            # Run the engine – here we call the stub run method.
            output_path = self.engine.run(self.selected_file)
            self.progress.setValue(100)
            self.status_label.setText(f"Done – saved to {output_path.name}")
            QMessageBox.information(self, "Finished", f"Upscaled video saved to:\n{output_path}")
        except Exception as exc:
            logger.exception("Engine run failed")
            QMessageBox.critical(self, "Error", str(exc))
        finally:
            self.start_btn.setEnabled(True)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # Apply a subtle window shadow via Qt attributes (works on Windows 10+)
    app.setAttribute(Qt.AA_UseHighDpiPixmaps)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())
