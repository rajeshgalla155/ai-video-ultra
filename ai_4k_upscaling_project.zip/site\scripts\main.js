// scripts/main.js
// Initialize AOS (already done inline) and any future interactive logic
document.addEventListener('DOMContentLoaded', () => {
    // Placeholder for future UI interactions (e.g., navigation highlighting)
});
